   #!/usr/bin/perl

#    use strict;
 #   use warnings;
 #   use File::NCopy;

    my $source_dir  = 'D:\Sandbox\Scripting\src\*';
    my $target_dir  = 'D:\Sandbox\Scripting\dest';

@files = glob($source_dir);

foreach(@files)
{
    print "\n $_";
    # . : any key, and * : any no. of times , (mandatory)
    if($_ =~m/.*(.txt)/)
    {
        print "\n Found Pattern";
    }
    else
    {
        print "\n unable to find the pattern";
    }


}
   #mkdir($target_dir) or die "Could not mkdir $target_dir: $!";

    #my $cp = File::NCopy->new(recursive => 1);
    #$cp->copy("$source_dir/*", $target_dir) 

   # or die "Could not perform rcopy of $source_dir to $target_dir: $!";

    #  $cp->copy($source_dir, $target_dir);   # This will fail
   # $cp->copy("$source_dir/*", $target_dir)  #....


