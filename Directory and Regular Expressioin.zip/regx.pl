
#pattern binding =~ and !~

print "enter data in string format :";

#my $userinput="You are Rocks";
$userinput = <STDIN>;


# . : any key, and * : any no. of times , (mandatory)
if($userinput =~m/.*(are).*/)
{
	print "Found Pattern";
}
else
{
	print "unable to find the pattern";
}


## example 2
my $var="Hello this is p";
if($var=~m/perl/)
{
	print "\n true"; 
} 
else
{
	print "\n False"; 
}


print "\n \n";
#Translation   : char by char 
my $a="hello how are you";
$a=~tr/hello/abcdm/;  # tr : translate 
print $a;

#Substitution  / change word 
print "\n \n";

my $a="Hello how are you";
$a=~s/Hello/abcd/gi; # s is substitute
print "\n $a";



