
use strict;
use File::Copy;
use File::Find;

my $age;
my $destination="/usr/local/netscape/server4/nes/publishdocs/press2/";
my $sourcedir="/usr/local/netscape/server4/nes/publishdocs/press/";

my @files=`cd $sourcedir && ls`;
my @dirlist=readdir(DIR);

# iterate and copy each one

sub cpnewest {
copy("$sourcedir$_","$destination$_"); 
}

foreach (@files, @dirlist){
chomp;
# get the age in seconds
$age = (time() - (stat($sourcedir.$_))[9]);
# if we files needs to be printed in unix
 print "\n$sourcedir.$_ is is $age seconds old\n";

if($age<120){
find(\&cpnewest, @dirlist);
}
}